package com.markbojensen.tipcalculator.util

import platform.Foundation.*

actual fun formatCurrency(value: Double): String {
    val formatter = NSNumberFormatter()
    formatter.numberStyle = NSNumberFormatterCurrencyStyle
    return formatter.stringFromNumber(NSNumber.numberWithDouble(value)) ?: "$value"
}

