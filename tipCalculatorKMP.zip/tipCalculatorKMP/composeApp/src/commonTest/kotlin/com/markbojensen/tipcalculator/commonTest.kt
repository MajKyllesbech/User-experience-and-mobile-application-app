package com.markbojensen.tipcalculator

import com.markbojensen.tipcalculator.util.formatCurrency
import kotlin.test.Test
import kotlin.test.assertEquals

class ComposeAppCommonTest {

}



