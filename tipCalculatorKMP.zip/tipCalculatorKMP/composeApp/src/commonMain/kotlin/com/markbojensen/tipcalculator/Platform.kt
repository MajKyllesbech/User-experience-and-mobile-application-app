package com.markbojensen.tipcalculator

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform