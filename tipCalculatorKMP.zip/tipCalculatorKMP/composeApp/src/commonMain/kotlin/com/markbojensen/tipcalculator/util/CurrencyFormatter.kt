package com.markbojensen.tipcalculator.util

expect fun formatCurrency(value: Double): String