package com.markbojensen.tipcalculator.util

import java.text.NumberFormat

actual fun formatCurrency(value: Double): String {
    return NumberFormat.getCurrencyInstance().format(value)
}

